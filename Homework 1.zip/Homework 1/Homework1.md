# Archive Folders in Windows
## Compress your folders when you archive them.
 If you don’t compress them, they will take up the same amount of disc space. Windows gives you the option to compress your folder at the same time you archive it.
 Steps:
 * Open the folder you want to archive
 * Click "Organize" on the top menu bar then click Properties
 * Click "advanced."
 * Click "folder is ready for archiving."
 * Click "compress contents to save disk space." (This step isn’t required to archive the folder, but it is advisable.)
  